<?php echo $__env->make('hr.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('hr.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">                
            <div class="page-content home">
                <style>
                    .home{
                        background-image: url("<?php echo e(asset('images/01.png')); ?>");
                        background-size: contain;
                        background-repeat: no-repeat;
                        background-position: center;
                    }
                </style>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
	<!-- endinject -->
	<!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/template.js')); ?>"></script>
	<!-- endinject -->
	<!-- custom js for this page -->
  <!-- end custom js for this page -->
  </body><?php /**PATH C:\xampp\htdocs\crm\crm\resources\views/hr/home.blade.php ENDPATH**/ ?>