<!-- <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="jquery.steps.min.js"></script>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-content">
                <div class="container">

                    <div class="row">
                        <div class="col-md-12 stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <?php if(Session::has('Record_updated')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(Session::get('Record_updated')); ?>

                                    </div>
                                    <?php endif; ?>

                                    <form class="cmxform" id="signupform" method="POST" action="<?php echo e(route('application.submit')); ?>" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        
                                        <h4 class="card-title">Application Form</h4>
                                        <div id="wizardVertical">
                                            <h2>Application Details</h2>
                                            <section style="overflow-y:auto;">
                                                <h4>Application Details</h4>
                                                <fieldset>
                                                    <div class="form-group">
                                                        <label for="salutation">Salutation</label>
                                                        <select class="btn btn-secondary form-control" id="salutation" name="salutation">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->title_id); ?>"><?php echo e($item->title); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <!-- <option value="student">Student</option> -->

                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="surname">Surname</label>
                                                        <input id="surname" class="form-control" name="surname" type="text">
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="firstname">First name</label>
                                                                <input id="firstname" class="form-control" name="firstname" type="text">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="middlename">Middle name</label>
                                                                <input id="middlename" class="form-control" name="middlename" type="text">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="dob">Date of birth</label>
                                                                <input type="date" class="form-control" name="dob" id="dob">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="email">Email</label>
                                                                <input id="email" class="form-control" name="email" type="email">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="gender">Gender</label>
                                                        <select class="btn btn-secondary form-control" id="gender" name="gender">
                                                            <option value""></option>
                                                            <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->gender_id); ?>"><?php echo e($item->gender); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <!-- <label for="confirm_password">Confirm password</label> -->
                                                        <label>Mobile Phone:</label>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <!-- <input class="form-control mb-4 mb-md-0" data-inputmask-alias="(+999) 9999-9999"/> -->
                                                                <select class="btn btn-secondary form-control" id="mobileshor" name="mobileshortcode">
                                                                    <option selected disabled></option>
                                                                    <?php $__currentLoopData = $countrycodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrycode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($countrycode->country_code_id); ?>"><?php echo e($countrycode -> country_code); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <input id="mobilephone" class="form-control" name="mobilephone" type="text">
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <!-- <label for="confirm_password">Confirm password</label> -->
                                                        <label>Home Phone:</label>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <!-- <input class="form-control mb-4 mb-md-0" data-inputmask-alias="(+999) 9999-9999"/> -->
                                                                <select class="btn btn-secondary form-control" id="homeshortcode">
                                                                    <option selected disabled></option>
                                                                    <?php $__currentLoopData = $countrycodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrycode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($countrycode -> country_code); ?>"><?php echo e($countrycode -> country_code); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <input id="homephone" class="form-control" name="homephone" type="text">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </section>

                                            <h2>Applicant Address</h2>
                                            <section style="overflow-y:auto">
                                                <h4>Application Address</h4>
                                                <fieldset>
                                                    <div class="form-group">
                                                        <label for="birthplace">Birth Place</label>
                                                        <input id="birthplace" class="form-control" name="birth_place" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="countryofbirth">Country of Birth / Nationality</label>
                                                        <select class="btn btn-secondary form-control" id="countryofbirth" name="countryofbirth">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->country_id); ?>"><?php echo e($item->country); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="citizenof">Citizen of</label>
                                                        <select class="btn btn-secondary form-control" id="citizenof" name="citizenof">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->country_id); ?>"><?php echo e($item->country); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="homestreetaddress">Home Street Address</label>
                                                        <input id="homestreetaddress" class="form-control" name="homestreetaddress" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="city">City</label>
                                                        <input id="city" class="form-control" name="city" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="postalcode">Postal code</label>
                                                        <input id="postalcode" class="form-control" name="postalcode" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="countryofresidence">Country of Residence</label>
                                                        <select class="btn btn-secondary form-control" id="countryofresidence" name="countryofresidence">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </fieldset>
                                            </section>

                                            <h2>Emergency Contact</h2>
                                            <section style="overflow-y:auto;">
                                                <h4>Emergency Contact</h4>
                                                <fieldset>
                                                    <div class="relationship">
                                                        <label for="name">Relationship to Applicant</label>
                                                        <select class="btn btn-secondary form-control" id="relationship" name="relationship">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($relationship->relationship_id); ?>"><?php echo e($relationship->relationship); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="firstnameofnok">First name of Emeregency Contact</label>
                                                        <input id="firstnameofnok" class="form-control" name="firstnameofnok" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="lastnameofnok">Last name of Emeregency Contact</label>
                                                        <input id="lastnameofnok" class="form-control" name="lastnameofnok" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="streetaddressnok">Street Address</label>
                                                        <input id="streetaddressnok" class="form-control" name="streetaddressnok" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="citynok">City</label>
                                                        <input id="citynok" class="form-control" name="citynok" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="postalcodenok">Postal Code (optional)</label>
                                                        <input id="postalcodenok" class="form-control" name="postalcodenok" type="text">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="provincenok">Province / State</label>
                                                        <select class="btn btn-secondary form-control" id="provincenok" name="provincenok">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($state->state_id); ?>"><?php echo e($state->state); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="countrynok">Country</label>
                                                        <select class="btn btn-secondary form-control" id="countrynok" name="countrynok">
                                                            <option selected disabled></option>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($country->country_id); ?>"><?php echo e($country->country); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <!-- <label for="confirm_password">Confirm password</label> -->
                                                        <label>Emergency Contact's Phone number</label>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <!-- <input class="form-control mb-4 mb-md-0" data-inputmask-alias="(+999) 9999-9999"/> -->
                                                                <select class="btn btn-secondary form-control" id="codenok" name="codenok">
                                                                    <option selected disabled></option>
                                                                    <?php $__currentLoopData = $countrycodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countrycode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($countrycode -> country_code_id); ?>"><?php echo e($countrycode -> country_code); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <input id="phonenok" class="form-control" name="phonenok" type="text">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="emailnok">Email (optional)</label>
                                                        <input id="emailnok" class="form-control" name="emailnok" type="email">
                                                    </div>
                                                </fieldset>
                                            </section>

                                            <h2>Requirements</h2>
                                            <section style="overflow-y:auto; overflow-x:hidden;">
                                                <h4>Requirements</h4>
                                                <fieldset>
                                                    <div class="form-group row">
                                                        <div class="col-md-6">
                                                            <label>Foundation / A Level</label>
                                                            <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                            <input type="file" name="alevel" id="alevel" class="file-upload-default">
                                                            <div class="input-group col-xs-12">
                                                                <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                                <span class="input-group-append">
                                                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Academic Qualification (SSCE)</label>
                                                            <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                            <input type="file" name="ssce" id="ssce" class="file-upload-default">
                                                            <div class="input-group col-xs-12">
                                                                <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                                <span class="input-group-append">
                                                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <div class="col-md-6">
                                                            <label>Letter of Sponsor</label>
                                                            <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                            <input type="file" name="sponsorletter" name="sponsorletter" class="file-upload-default">
                                                            <div class="input-group col-xs-12">
                                                                <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                                <span class="input-group-append">
                                                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Reference Letter (Academic)</label>
                                                            <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                            <input type="file" name="refletter" id="refletter" class="file-upload-default">
                                                            <div class="input-group col-xs-12">
                                                                <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                                <span class="input-group-append">
                                                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <div class="col-md-6">
                                                            <label>Reference Letter (Work)</label>
                                                            <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                            <input type="file" name="refletterwork" id="refletterwork" class="file-upload-default">
                                                            <div class="input-group col-xs-12">
                                                                <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                                <span class="input-group-append">
                                                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label>Copy of Testimonial</label>
                                                            <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                            <input type="file" name="testimonial" id="testimonial" class="file-upload-default">
                                                            <div class="input-group col-xs-12">
                                                                <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                                <span class="input-group-append">
                                                                    <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>English Proficiency Test Results (IELTS, TOEFL, PTE and otheres if applicable)</label>
                                                        <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                        <input type="file" name="proficiency" id="proficiency" class="file-upload-default">
                                                        <div class="input-group col-xs-12">
                                                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                            <span class="input-group-append">
                                                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="personalstatement">Personal Statement or Letter of Intent</label>
                                                        <textarea class="form-control" id="personalstatement" rows="5"></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Data Page of International Passport </label>
                                                        <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                        <input type="file" name="datapage" id="datapage" class="file-upload-default">
                                                        <div class="input-group col-xs-12">
                                                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                            <span class="input-group-append">
                                                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="appfee">Application Fee (if available)</label>
                                                                <input id="appfee" class="form-control" name="appfee" type="text">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="servicefee">Service Fee</label>
                                                                <input id="servicefee" class="form-control" name="servicefee" type="text">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </fieldset>
                                            </section>
                                            <h2>Program Type</h2>
                                            <section style="overflow-y:auto;">
                                                <h4>Program Type</h4>
                                                <div class="form-group">
                                                    <label for="progtype">Select Program Type</label>
                                                    <select class="btn btn-secondary form-control" name="progtype" id="progtype">
                                                        <option selected disabled></option>
                                                        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($program->program_type_id); ?>"><?php echo e($program->program_type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="one">
                                                    <div class="form-group">
                                                        <label>Upload A-Level Diploma / Transcript</label>
                                                        <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                        <input type="file" name="diplomatranscript" id="diplomatranscript" class="file-upload-default">
                                                        <div class="input-group col-xs-12">
                                                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                            <span class="input-group-append">
                                                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="two">
                                                    <div class="form-group">
                                                        <label>Degree Certificate or Statement of Result</label>
                                                        <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                        <input type="file" name="degreecert" id="degreecert" class="file-upload-default">
                                                        <div class="input-group col-xs-12">
                                                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                            <span class="input-group-append">
                                                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Undergraduate Transcript</label>
                                                        <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                        <input type="file" name="undergradtranscript" id="undergradtranscript" class="file-upload-default">
                                                        <div class="input-group col-xs-12">
                                                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                            <span class="input-group-append">
                                                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Updated CV</label>
                                                        <!-- <input type="file" name="img[]" class="file-upload-default"> -->
                                                        <input type="file" name="cv" id="cv" class="file-upload-default">
                                                        <div class="input-group col-xs-12">
                                                            <input type="text" class="form-control file-upload-info" disabled="" placeholder="Upload Image">
                                                            <span class="input-group-append">
                                                                <button class="file-upload-browse btn btn-primary" type="button">Upload</button>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <!-- <input type="submit" name="submit" class="submit action-button" value="Submit" /> -->
                                                </div>
                                            </section>
                                        </div>
                                        <button type="submit" class="">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('vendors/jquery-validation/jquery.validate.min.js')); ?>"></script> -->

    <!-- <script src="<?php echo e(asset('vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/datepicker.js')); ?>"></script> -->
    <!-- ------- -->
    <script src="<?php echo e(asset('js/inputmask.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/inputmask/jquery.inputmask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/jquery-tags-input/jquery.tagsinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tags-input.js')); ?>"></script>

    <!-- --------- -->
    <!-- endinject -->
    <!-- plugin js for this page -->
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- custom js for this page -->
    <script src="<?php echo e(asset('js/wizard.js')); ?>"></script>
    <!-- custom js for this page -->
    <!-- end custom js for this page -->
    <!-- plugin js for this page -->
    <script src="<?php echo e(asset('vendors/jquery-steps/jquery.steps.min.js')); ?>"></script>
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <!-- <script src="../../../assets/vendors/feather-icons/feather.min.js"></script> -->
    <!-- <script src="../../../assets/js/template.js"></script> -->
    <!-- endinject -->
    <script src="<?php echo e(asset('js/file-upload.js')); ?>"></script>
    <!-- custom js for this page -->
    <!-- <script src="../../../assets/js/wizard.js"></script> -->
    <script src="<?php echo e(asset('js/form-validation.js')); ?>"></script>
    <!-- end custom js for this page -->
</body>

</html><?php /**PATH C:\Users\DELL\Desktop\newCrm\crm\resources\views/application.blade.php ENDPATH**/ ?>