<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>IEISCRM</title>
	<!-- core:css -->
	<link rel="stylesheet" href="<?php echo e(asset('vendors/core/core.css')); ?>">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
  <!-- end plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('fonts/feather-font/css/iconfont.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
  <!-- endinject -->
  <!-- Layout styles -->  
  <link rel="stylesheet" href="<?php echo e(asset('css/demo_1/style.css')); ?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo e(asset('images/logo.png')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/jquery-steps/jquery.steps.css')); ?>">
	

  
<?php /**PATH C:\xampp\htdocs\crm\crm\resources\views/layouts/header.blade.php ENDPATH**/ ?>