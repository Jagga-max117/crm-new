<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-content">
              <?php if(Session::has('enquiry_created')): ?>
                   <div class="alert alert-success">
                        <?php echo e(Session::get('enquiry_created')); ?>

                  </div>
                 <?php endif; ?>
                <div class="row">
                    <div class="col-lg-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Enquiry</h3>
                                <form class="cmxform" id="signupForm" method="post" action="<?php echo e(route('enquiry.submit')); ?>">
                                  <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            
                                            <fieldset>
                                                <div class="form-group">
                                                <label for="name">Salutation</label>
                                                    <select name="salutation" class="btn btn-secondary form-control" id="salutation">
                                                      
                                                        <option  value="">Title</option>
                                                        <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->title_id); ?>"><?php echo e($item->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label for="fname">Firstname</label>
                                                    <input id="first_name" class="form-control" name="first_name" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="email">Email Address</label>
                                                    <input id="email" class="form-control" name="email" type="email">
                                                </div>
                                                <div class="form-group">
                                                <label for="name">Proposed Level of Study</label>
                                                    <select name="study_level" id="study_level" class="btn btn-secondary form-control">
                                                        <option value="">Level</option>
                                                        <?php $__currentLoopData = $program_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->program_type_id); ?>"><?php echo e($item->program_type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                <label for="name">Proposed Course of Study</label>
                                                    <select class="btn btn-secondary form-control" name="course_of_study" id="course_of_study">
                                                        <option value="">Course</option>
                                                        <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->course_id); ?>"><?php echo e($item->course); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                <label for="name">How did you hear about IEIS?</label>
                                                    <select class="btn btn-secondary form-control" name="how_did_you_hear_about_ieis" id="how_did_you_hear_about_ieis">
                                                      <?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="">About</option>
                                                        <option value="<?php echo e($item->information_id); ?>"><?php echo e($item->information); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <!-- <option value="student">Miss</option> -->
                                                    </select>
                                                </div>
                                            </fieldset>
                                        </div>
                                        <div class="col-md-6">
                                            <fieldset>
                                                <div class="form-group">
                                                    <label for="name">Surname</label>
                                                    <input id="surname" class="form-control" name="surname" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="fname">Middle name</label>
                                                    <input id="middle_name" class="form-control" name="middle_name" type="text">
                                                </div>
                                                <div class="form-group">
                                                    <label for="phone">Phone Number</label>
                                                    <input id="phone_number" class="form-control" name="phone_number" type="text">
                                                </div>
                                                <div class="form-group">
                                                <label for="name">Area of Subject Interest</label>
                                                    <select class="btn btn-secondary form-control" name="subject_area" id="subject_area">
                                                      <?php $__currentLoopData = $subject_area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="">Subject</option>
                                                        <option value="<?php echo e($item->subject_area_id); ?>"><?php echo e($item->subject_area); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                <label for="name">Preferred School</label>
                                                    <select class="btn btn-secondary form-control" name="preferred_school" id="preferred_school">
                                                        <option value=""></option>
                                                      <?php $__currentLoopData = $school; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->school_id); ?>"><?php echo e($item->school); ?></option>
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                <label for="name">How did you hear about the preferred School?</label>
                                                    <select class="btn btn-secondary form-control" name="how_did_you_hear_about_school" id="how_did_you_hear_about_school">
                                                        <option value="">About School</option>
                                                      <?php $__currentLoopData = $information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->information_id); ?>"><?php echo e($item->information); ?></option>
                                                        <!-- <option value="student">Miss</option> -->
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </fieldset>
                                        </div>
                                        
                                    </div>
                                    <input class="btn btn-primary float-right" type="submit" value="Submit">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- custom js for this page -->
    <!-- end custom js for this page -->
</body><?php /**PATH C:\xampp\htdocs\crm\crm\resources\views/enquiry.blade.php ENDPATH**/ ?>