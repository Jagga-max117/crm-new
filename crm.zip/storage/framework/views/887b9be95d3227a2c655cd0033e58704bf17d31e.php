<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<!-- plugin css for this page -->
<link rel="stylesheet" href="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
<!-- end plugin css for this page -->
</title>
<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">                
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-content">
                
            <div class="row">
					<div class="col-lg-12 grid-margin stretch-card">
						<div class="card">
							<div class="card-body">
								<h4 class="card-title">Gender</h4>
								<p class="card-description"></p>
                                <?php if(Session::has('Record_deleted')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(Session::get('Record_deleted')); ?>

                                    </div>    
                                <?php endif; ?>
								<form class="cmxform" id="signupForm" method="post" action="<?php echo e(route('gender.submit')); ?>">
									<?php echo csrf_field(); ?>
                                    <fieldset>
										<div class="form-group">
											<label for="gender">Enter Gender</label>
											<input id="name" class="form-control" name="gender" type="text">
										</div>
										<input class="btn btn-primary" type="submit" value="Submit">
									</fieldset>
								</form>
							</div>
						</div>
					</div>
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title"></h6>
                                <p class="card-description"></p>
                                <div class="table-responsive">
                                <table id="dataTableExample" class="table">
                                    <thead>
                                        <th>List of Gender</th>
                                    </thead>
                                    <tbody>
                                       <?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                            <td><?php echo e($gender->gender); ?></td>
                                            <td><a href="/delete-gender/<?php echo e($gender->gender_id); ?>" class="btn btn-danger">Delete</a></td>
                                       </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
					</div>
				</div>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
	<!-- endinject -->
	<!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/template.js')); ?>"></script>
	<!-- endinject -->
    <!-- plugin js for this page -->
    <script src="<?php echo e(asset('vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
	<!-- end plugin js for this page -->
	<!-- custom js for this page -->
    <script src="<?php echo e(asset('js/data-table.js')); ?>"></script>
    <!-- end custom js for this page -->
  </body>
  </html><?php /**PATH C:\Users\DELL\Desktop\newCrm\crm\resources\views/gender.blade.php ENDPATH**/ ?>