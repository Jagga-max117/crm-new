<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-content">
                <div class="row">
                    <div class="card-deck col-12 col-xl-12 stretch-card">
                        <!-- ============================================ -->
                        <div class="col-12 col-md-2 col-xl-2">
                                <a href="/profile">
                                <div class="card text-center">
                                    <img src="<?php echo e(asset('images/hoodie.png')); ?>" class="card-img-top" alt="...">
                                    <div class="card-body">
                                        <h5 class="card-title"><strong>Ade M. Ola</strong></h5>
                                        <p>University of York</p>
                                        <p class="card-text"><small class="text-muted">Accepted</small></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <!-- ============================================ -->
                    </div>
                </div>
                <!-- <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title"></h6>
                                <p class="card-description"></p>
                                <div class="table-responsive">
                                <table id="dataTableExample" class="table">
                                    <thead>
                                        <th>Title</th>
                                        <th>Name</th>
                                        <th>Gender</th>
                                        <th>Email</th>
                                        <th>Nationality</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                       <tr>
                                            <td>Mr</td>
                                            <td>Ade Ola</td>
                                            <td>Male</td>
                                            <td>ade100@amail.com</td>
                                            <td>Nigeria</td>
                                            <td><a href="#" class="btn btn-primary">View</a></td>
                                        </tr>
                                       <tr>
                                            <td>Mr</td>
                                            <td>Ade Ola</td>
                                            <td>Male</td>
                                            <td>ade100@amail.com</td>
                                            <td>Nigeria</td>
                                            <td><a href="#" class="btn btn-primary">View</a></td>
                                        </tr>
                                       <tr>
                                            <td>Mr</td>
                                            <td>Ade Ola</td>
                                            <td>Male</td>
                                            <td>ade100@amail.com</td>
                                            <td>Nigeria</td>
                                            <td><a href="#" class="btn btn-primary">View</a></td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
					</div>-->
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- custom js for this page -->
    <!-- end custom js for this page -->
</body>

</html><?php /**PATH C:\Users\DELL\Desktop\newCrm\crm\resources\views/my-students.blade.php ENDPATH**/ ?>