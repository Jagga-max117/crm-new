<?php echo $__env->make('hr.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('hr.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">                
            <?php echo $__env->make('hr.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-content">
                <h3 class="text-center">LOAN HISTORY</h3>
            <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title"></h6>
                                <p class="card-description"></p>
                                <div class="table-responsive">
                                <table id="dataTableExample" class="table text-center">
                                    <thead>
                                        <th>Loan Date</th>
                                        <th>Loan Type</th>
                                        <th>Amount</th>
                                        <th>Tenor</th>
                                        <th>Repayment Amount</th>
                                        <th>File</th>
                                    </thead>
                                    <tbody>
                                       <tr>
                                            <td>18-03-2020</td>
                                            <td>---</td>
                                            <td>₦---</td>
                                            <td>---</td>
                                            <td>---</td>
                                            <td>---</td>
                                        </tr>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                        </div>
					</div>
            </div>
            <?php echo $__env->make('hr.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
	<!-- endinject -->
	<!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/template.js')); ?>"></script>
	<!-- endinject -->
	<!-- custom js for this page -->
  <!-- end custom js for this page -->
  </body><?php /**PATH C:\xampp\htdocs\crm\crm\resources\views/hr/loan-history.blade.php ENDPATH**/ ?>