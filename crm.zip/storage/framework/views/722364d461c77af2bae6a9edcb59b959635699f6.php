<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="sidebar-dark">
    <div class="main-wrapper">
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-content">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title"></h6>
                            <p class="card-description"></p>
                            <div class="table-responsive">
                                <table id="dataTableExample" class="table">
                                    <thead>

                                        <th>S/N</th>
                                        <th>Title</th>
                                        <th>First_name</th>
                                        <th>Surname</th>
                                        <th>Email</th>
                                        <th>Phone_number</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $enquiry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <?php $__currentLoopData = $title; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if( $item->title_id === $posts->salutation): ?>
                                            <td><?php echo e($item->title); ?></td>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <td><?php echo e($posts->first_name); ?></td>
                                            <td><?php echo e($posts->surname); ?></td>
                                            <td><?php echo e($posts->email); ?></td>
                                            <td><?php echo e($posts->phone_number); ?></td>
                                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($items->status_id === $posts->status): ?>
                                            <td><?php echo e($items->status); ?></td>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







                                            <td>
                                                <form id="form" action="<?php echo e(route('statusupdate')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($posts->id); ?>">


                                                    <select class="custom-select" name="status" id="status">

                                                        <option value="">select status</option>
                                                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        <option type="hidden" name="status" value="<?php echo e($posts->status_id); ?>"><?php echo e($posts->status); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <!-- <a class="" id="" href="javascript:void(0)" onclick="$('#form').submit()"><i data-feather="edit-3"></i></a> -->
                                                    <button type="submit" class="btn btn-primary">UPDATE</button>
                                                </form>
                                            </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <script src="<?php echo e(asset('vendors/core/core.js')); ?>"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('vendors/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- custom js for this page -->
    <!-- end custom js for this page -->
</body>

</html><?php /**PATH C:\Users\DELL\Desktop\newCrm\crm\resources\views/status.blade.php ENDPATH**/ ?>