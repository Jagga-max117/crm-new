@include('layouts.header')
</head>

<body class="sidebar-dark">
    <div class="main-wrapper">
        @include('layouts.sidebar')
        <div class="page-wrapper">
            @include('layouts.navbar')
            <div class="page-content">

                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title"></h6>
                            <p class="card-description"></p>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="fromdate">From</label>
                                        <input type="date" class="form-control" name="fromdate" id="fromdate">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="todate">To</label>
                                        <input type="date" class="form-control" name="todate" id="todate">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="gender">Filter</label>
                                        <select class="btn btn-secondary form-control" id="gender" name="gender">
                                            <option selected disabled>No filter</option>
                                            <option value="">Male</option>
                                            <option value="">Female</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-md-4"></div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary col-md-12" type="button">View</button>
                                </div>
                                <div class="col-md-4"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title"></h6>
                            <p class="card-description"></p>
                            <div class="row">
                                <div class="col-md-4">
                                    <button class="btn btn-primary col-md-12" type="button">Export to PDF</button>
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary col-md-12" type="button">Export to Excel</button>
                                </div>
                                <div class="col-md-4">
                                    <button class="btn btn-primary col-md-12" type="button">Export to Word</button>
                                </div>
                            </div>
                            <table id="dataTableExample" class="table mt-4">
                                    <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Full name</th>
                                        <th>Email Address</th>
                                        <th>Phone number</th>
                                        <th>Preferred Level<br /> of Study</th>
                                        <th>Preferred Course<br /> of Study</th>
                                        <th>Area of Subject Area</th>
                                        <th>Gender</th>
                                        <th>Preferred School</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                       <tr>
                                            
                                       </tr>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>

            </div>
            @include('layouts.footer')
        </div>
    </div>
    <script src="{{ asset('vendors/core/core.js') }}"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <script src="{{ asset('vendors/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('js/template.js') }}"></script>
    <!-- endinject -->
    <!-- custom js for this page -->
    <!-- end custom js for this page -->
</body>