<?php

namespace App\Http\Controllers;

use App\Models\Country;
use App\Models\Relationship;
use App\Models\Country_code;
use App\Models\Gender;
use App\Models\Program_type;
use App\Models\Title;
use App\Models\State;
use App\Models\Application;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Dotenv\Validator;
// use Illuminate\Database\Eloquent\Factories\Relationship;
use Illuminate\Support\Facades\Auth;
// use PharIo\Manifest\Application;





class PostController extends Controller
{
    // public function getuserroles(){
    //     $userroles = DB::table('userroles')->get();
    //     return view('country-codes', compact('userroles'));
    // }
    //----- course -----
    public function getcourse()
    {
        $courses = DB::table('course')->get();
        return view('course', compact('courses'));
    }
    // public function addpost(){
    //     return view('addcourse');
    // }
    public function addcoursesubmit(Request $request)
    {
        DB::table('course')->insert([
            'course' => $request->course
        ]);
        return redirect('course');
    }
    public function delcourse($id)
    {
        DB::table('course')->where('course_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been deleted successfully!');
    }
    //----- countrycodes -----
    public function getcountrycodes()
    {
        $countrycodes = DB::table('country_code')->get();
        $countries = DB::table('country')->get();
        return view('country-codes', compact('countrycodes', 'countries'));
    }
    // public function addcountrycodes(Request $request){
    //     DB::table('country_code')->insert([
    //         'country_code'=> $request -> countrycode
    //     ]);
    //     return back()->with('post_created', 'Updated succssfully!');
    //     // return redirect('country-codes');
    // }
    public function addcountrycodes(Request $request)
    {
        // $request = DB::table('country_code')->join('country', 'country.id' , '=', 'country_code.code')
        //              ->select('country.country', 'country_code.code')->get();
        // // return back()->with('post_created', 'Updated succssfully!');
        // return $request;
        // return redirect('country-codes');
        // $request = DB::table('country_code');
        // ->leftJoin('country', 'country.country_id', '=', 'country_code.country_code_id');
        // ->insert([
        // 'country_code'=> $request->country_code[3],
        // 'country' => $request->country[1]
        // ]);
        // var_dump($request->country_code);

        // return back();

        $country = ($_POST["country"]);
        $countrycode = ($_POST["countrycode"]);
        DB::table('country_code')->insert([
            // 'country' => $country,
            'code' => $countrycode,
            'country_code' => $country . ' ' . $countrycode
        ]);

        return back();
    }
    public function delcountrycode($id)
    {
        DB::table('country_code')->where('country_code_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted');
    }
    // ---------------gender----------
    public function getgender()
    {
        $genders = DB::table('gender')->get();
        return view('gender', compact('genders'));
    }
    public function addgender(Request $request)
    {
        DB::table('gender')->insert([
            'gender' => $request->gender
        ]);
        return back();
    }
    public function delgender($id)
    {
        DB::table('gender')->where('gender_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been deleted successfully!');
    }
    // -----------------entranceterm----------------
    public function getentranceterm()
    {
        $entranceterms = DB::table('entrance_term')->get();
        return view('entrance-term', compact('entranceterms'));
    }
    public function addentranceterm(Request $request)
    {
        DB::table('entrance_term')->insert([
            'entrance_term' => $request->entranceterm
        ]);
        return back();
    }
    public function delentranceterm($id)
    {
        DB::table('entrance_term')->where('entrance_term_id', $id)->delete();
        return back()->with("Record_deleted", "Record has been successfully deleted!");
    }
    // --------------------getcountries-----------
    public function getcountries()
    {
        $countries = DB::table('country')->get();
        return view('countries', compact('countries'));
    }
    public function addcountries(Request $request)
    {
        DB::table('country')->insert([
            'country' => $request->country
        ]);
        return back();
    }
    public function delcountries($id)
    {
        DB::table('country')->where('country_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    //-------------states---------------
    public function getstates()
    {
        $states = DB::table('state')->get();
        return view('state', compact('states'));
    }
    public function addstates(Request $request)
    {
        DB::table('state')->insert([
            'state' => $request->state
        ]);
        return back();
    }
    public function delstates($id)
    {
        DB::table('state')->where('state_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // -----------relationships------
    public function getrelationships()
    {
        $relationships = DB::table('relationship')->get();
        return view('relationship', compact('relationships'));
    }
    public function addrelationships(Request $request)
    {
        DB::table('relationship')->insert([
            'relationship' => $request->relationship
        ]);
        return back();
    }
    public function delrelationships($id)
    {
        DB::table('relationship')->where('relationship_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // -------------student-type---------
    public function getstudenttype()
    {
        $studenttypes = DB::table('student_type')->get();
        return view('student-type', compact('studenttypes'));
    }
    public function addstudenttype(Request $request)
    {
        DB::table('student_type')->insert([
            'student_type' => $request->studenttype
        ]);
        return back();
    }
    public function delstudenttype($id)
    {
        DB::table('student_type')->where('student_type_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // ---------program-type----------
    public function getprogramtype()
    {
        $programtypes = DB::table('program_type')->get();
        return view('program-type', compact('programtypes'));
    }
    public function addprogramtype(Request $request)
    {
        DB::table('program_type')->insert([
            'program_type' => $request->programtype
        ]);
        return back();
    }
    public function delprogramtype($id)
    {
        DB::table('program_type')->where('program_type_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // ----------titles-----------
    public function gettitles()
    {
        $titles = DB::table('title')->get();
        return view('title', compact('titles'));
    }
    public function addtitles(Request $request)
    {
        DB::table('title')->insert([
            'title' => $request->title
        ]);
        return back();
    }
    public function deltitle($id)
    {
        DB::table('title')->where('title_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // -------------subjectarea------------------
    public function getsubjectarea()
    {
        $subjectareas = DB::table('subject_area')->get();
        return view('subject-area', compact('subjectareas'));
    }
    public function addsubjectarea(Request $request)
    {
        DB::table('subject_area')->insert([
            'subject_area' => $request->subjectarea
        ]);
        return back();
    }
    public function delsubjectarea($id)
    {
        DB::table('subject_area')->where('subject_area_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // -------school-------
    public function getschool()
    {
        $schools = DB::table('school')->get();
        return view('school', compact('schools'));
    }
    public function addschool(Request $request)
    {
        DB::table('school')->insert([
            'school' => $request->school
        ]);
        return back();
    }
    public function delschool($id)
    {
        DB::table('school')->where('school_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // ---------information--------
    public function getinformation()
    {
        $info = DB::table('information')->get();
        return view('information', compact('info'));
    }
    public function addinformation(Request $request)
    {
        DB::table('information')->insert([
            'information' => $request->information
        ]);
        return back();
    }
    public function delinformation($id)
    {
        DB::table('information')->where('information_id', $id)->delete();
        return back()->with('Record_deleted', 'Record has been successfully deleted!');
    }
    // =======user========
    public function adduser(Request $request)
    {
        DB::table('user')->insert([
            'user' => $request->user
        ]);
        return back();
    }
    // ==============application================
    public function getapplication()
    {
        $title = Title::orderBy('title_id', 'ASC')->get();;
        $genders = Gender::orderBy('gender_id')->get();
        $countrycodes = Country_code::orderBy('country_code_id')->get();
        $countries = Country::orderBy('country_id')->get();
        $relationships = Relationship::orderBy('relationship_id')->get();
        $states = State::orderBy('state_id')->get();
        $programs = Program_type::orderby('program_type_id', 'ASC')->get();
        return view('application', compact('title', 'genders', 'countrycodes', 'countries', 'relationships', 'states', 'programs'));
    }
    public function addapplication(Request $request)
    {

        $post = new Application();

        $post->salutation = $request->salutation;
        $post->surname = $request->surname;
        $post->firstname = $request->firstname;
        $post->middlename = $request->middlename;
        $post->date = $request->dob;
        $post->email = $request->email;
        $post->gender = $request->gender;
        $post->mobile_short_code = $request->mobileshortcode;
        $post->mobile_phone = $request->mobilephone;
        $post->home_short_code = $request->homeshortcode;
        $post->home_phone = $request->homephone;
        $post->birth_place = $request->birthplace;
        $post->country_of_birth = $request->countryofbirth;
        $post->citizenof = $request->citizenof;
        $post->home_street_address = $request->homestreetaddress;
        $post->city = $request->city;
        $post->postal_code = $request->postalcode;
        $post->country_of_residence = $request->countryofresidence;
        $post->relationship_to_applicant = $request->relationship;
        $post->firstname_of_nok = $request->firstnameofnok;
        $post->lastname_of_nok = $request->lastnameofnok;
        $post->street_address_of_nok = $request->streetaddressnok;
        $post->city_of_nok = $request->citynok;
        $post->postal_code_of_nok = $request->postalcodeofnok;
        $post->province_of_nok = $request->provincenok;
        $post->country_of_nok = $request->countrynok;
        $post->code_of_nok = $request->codenok;
        $post->phone_of_nok = $request->phonenok;
        $post->email_of_nok = $request->emailnok;
        $post->a_level = $request->alevel;
        $post->ssce = $request->ssce;
        $post->sponsor_letter = $request->sponsorletter;
        $post->academic_ref_letter = $request->refletter;
        $post->work_ref_letter = $request->refletterwork;
        $post->testimonial = $request->testimonial;
        $post->proficiency = $request->proficiency;
        $post->personal_statement = $request->personalstatement;
        $post->data_page = $request->datapage;
        $post->app_fee = $request->appfee;
        $post->service_fee = $request->servicefee;
        $post->program_type = $request->progtype;
        $post->diploma_transcript = $request->diplomatranscript;
        $post->degree_cert = $request->degreecert;
        $post->undergrad_transcript = $request->undergradtranscript;
        $post->cv = $request->cv;
        // dd($post);
        $post->save();
        return back()->with('Record_updated', 'Your record has been successfully saved!');
    }
    function index()
    {
        return view('signin');
    }
    function checklogin(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $user_data = array(
            'email' => $request->get('email'),
            'password' => $request->get('password'),
        );
        if (Auth::attempt($user_data)) {
            return redirect('main/successlogin');
        } else {
            return back()->with('error', 'Wrong details');
        }
    }
    function sucesslogin()
    {
        return view('successlogin');
    }
    function logout()
    {
        Auth::logout();
        return redirect('main');
    }

    public function viewapplication()
    {
        $application = DB::select("SELECT *, enquiry.status, enquiry.id as id FROM enquiry
        LEFT JOIN status ON status.`status_id` = enquiry.`status`
        LEFT JOIN title ON title.`title` = enquiry.`salutation`");
        // dd($enquiry);
        $status = Status::orderBy('status_id', 'ASC')->get();
        $title = Title::orderBy('title_id', 'ASC')->get();

        // dd($status);



        return view('status', compact('enquiry', 'status', 'title'));
    }

    public function getreport()
    {
        return view('report');
    }
}
